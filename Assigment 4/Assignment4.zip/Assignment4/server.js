/*********************************************************************************
* WEB700 – Assignment 04
* I declare that this assignment is my own work in accordance with Seneca Academic Policy. No part
* of this assignment has been copied manually or electronically from any other source
* (including 3rd party web sites) or distributed to other students.
*
* Name: Neel Hiren Bamania Student ID: 160262234 Date: 18th July, 2024
* Online (Heroku) Link: https://damp-cove-89991-3dc2aade3787.herokuapp.com/
*
********************************************************************************/

const express = require('express');
const path = require('path');
const collegeData = require('./collegeDATA');

const app = express();
const HTTP_PORT = process.env.PORT || 8080;

app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Route to get all TAs
app.get('/tas', (req, res) => {
    collegeData.getTAs().then(tas => {
        res.json(tas);
    }).catch(err => {
        res.json({ message: "no results" });
    });
});

// Route to get all courses
app.get('/courses', (req, res) => {
    collegeData.getCourses().then(courses => {
        res.json(courses);
    }).catch(err => {
        res.json({ message: "no results" });
    });
});

// Route to get all students
app.get('/students', (req, res) => {
    const course = req.query.course;
    if (course) {
        collegeData.getStudentsByCourse(course).then(students => {
            res.json(students);
        }).catch(err => {
            res.json({ message: "no results" });
        });
    } else {
        collegeData.getAllStudents().then(students => {
            res.json(students);
        }).catch(err => {
            res.json({ message: "no results" });
        });
    }
});

// Route to get a single student by student number
app.get('/student/:num', (req, res) => {
    const studentNum = req.params.num;
    collegeData.getStudentByNum(studentNum).then(student => {
        res.json(student);
    }).catch(err => {
        res.json({ message: "no results" });
    });
});

// Route to return home.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '/views/home.html'));
});

// Route to return about.html
app.get('/about', (req, res) => {
    res.sendFile(path.join(__dirname, '/views/about.html'));
});

// Route to return htmlDemo.html
app.get('/htmlDemo', (req, res) => {
    res.sendFile(path.join(__dirname, '/views/htmlDemo.html'));
});

// Route to return addStudent.html
app.get('/students/add', (req, res) => {
    res.sendFile(path.join(__dirname, '/views/addStudent.html'));
});

// Route to handle adding a student
app.post('/students/add', (req, res) => {
    collegeData.addStudent(req.body).then(() => {
        res.redirect('/students');
    }).catch(err => {
        res.json({ message: "unable to add student" });
    });
});

// Catch-all route for unmatched routes
app.use((req, res) => {
    res.status(404).send("Page Not THERE, Are you sure of the path?");
});

// Initialize and start the server
collegeData.initialize().then(() => {
    app.listen(HTTP_PORT, () => {
        console.log(`Server listening on port ${HTTP_PORT}`);
    });
}).catch(err => {
    console.error(`Failed to initialize data: ${err}`);
});
